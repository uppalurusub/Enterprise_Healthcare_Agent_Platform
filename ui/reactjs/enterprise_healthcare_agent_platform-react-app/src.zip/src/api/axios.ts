import axios from "axios";

export default axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || "http://localhost:8000/api/v1",
  timeout: 30000,
  headers: {"Content-Type":"application/json"}
});